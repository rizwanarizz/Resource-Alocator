from django.urls import path,include
from.import views

urlpatterns=[

    path('',views.trainers_form,name="trainers_insert"),
    path('list/',views.trainers_list,name="trainers_list"),
    path('<int:id>/',views.trainers_form,name="trainers_update"),
    path('delete/<int:id>',views.trainers_delete,name="trainers_delete"),

]
