from django.shortcuts import render,redirect
from.forms import Trainersform
from.models import Trainers

# Create your views here.
def trainers_form(request,id=0):
    if request.method =="GET":
        if id == 0:
            form = Trainersform # Instantiate the form
        else:
            trainer = Trainers.objects.get(pk=id)
            form = Trainersform(instance=trainer)
        return render(request,'trainerapp/trainers_form.html',{'form':form})
    else:
        if id==0:
            form=Trainersform(request.POST)
        else:
            trainer=Trainers.objects.get(pk=id)
            form=Trainersform(request.POST,instance=trainer)
        if form.is_valid():
            form.save()
        return redirect("trai/list/")

def trainers_list(request):
        context={'trainers_list':Trainers.objects.all()}
        return render(request, 'trainerapp/trainers_list.html', context)

def trainers_update(request):
    return

def trainers_delete(request,id):
    trainer=Trainers.objects.get(pk=id)
    trainer.delete()
    return redirect('/trai/list/')