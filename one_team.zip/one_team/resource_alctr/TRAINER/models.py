from django.db import models
from SETTINGS.models import *

# Create your models here.
   
class Trainers(models.Model):
    name =  models.ForeignKey(Trainer,on_delete=models.CASCADE)
    genders = (
        ("m","male"),
        ("f","female"),
        ("o","other")
    )
    gender = models.CharField(max_length=10,choices=genders)
    course = models.ForeignKey(Course,on_delete=models.CASCADE)
    SLOT_CHOICES = [
        ('9.00 am - 10.30 am', '9.00 am - 10.30 am'),
        ('10.30 am - 12.00 pm', '10.30 am - 12.00 pm'),
        ('12.00 pm - 1.30 pm', '12.00 pm - 1.30 pm'),
        ('2.00 pm - 3.30 pm', '2.00 pm - 3.30 pm'),
        ('3.30 pm - 5.00 pm', '3.30 pm - 5.00 pm'),
    ]
    slot = models.CharField(max_length=100, choices=SLOT_CHOICES)

 

    

 