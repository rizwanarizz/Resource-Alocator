from django.contrib import admin
from .models import Trainers

class TrainersAdmin(admin.ModelAdmin):
    list_display = ('name', 'gender', 'slot', 'course')

admin.site.register(Trainers, TrainersAdmin)





# from django import forms
# from django.contrib import admin
# from .models import Trainers

# class TrainersForm(forms.ModelForm):
#     class Meta:
#         model = Trainers
#         fields = '__all__'
#         widgets = {
#             'name': forms.Select(attrs={'class': 'select2'}),
#             'slot': forms.Select(attrs={'class': 'select2'}),
#         }

#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)

#         if 'name' in self.fields:
#             # Get all slots
#             all_slots = dict(Trainers.SLOT_CHOICES)
#             # Exclude slots that have already been taken by any trainer
#             taken_slots = Trainers.objects.exclude(slot__isnull=True).values_list('slot', flat=True)
#             available_slots = [(key, value) for key, value in all_slots.items() if key not in taken_slots]
#             self.fields['slot'].choices = available_slots

# class TrainersAdmin(admin.ModelAdmin):
#     form = TrainersForm
#     list_display = ('name', 'gender', 'slot', 'course')

# admin.site.register(Trainers, TrainersAdmin)
