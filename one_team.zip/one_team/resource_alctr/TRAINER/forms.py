from django import forms
from.models import Trainers


class Trainersform(forms.ModelForm):
    class Meta:
        model=Trainers
        fields="__all__"