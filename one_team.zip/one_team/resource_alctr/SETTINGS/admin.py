from django.contrib import admin
from .models import Companies,Trainer, Course, States, Districts, Branches, Enquiry_Source, Follow_up_status, Qualification, Batch, Syllabus,Slot,Device_num, Brands,Class

@admin.register(Companies)
class CompaniesAdmin(admin.ModelAdmin):
    list_display = ('company', 'adress_1', 'adress_2', 'phone_number', 'Email', 'website', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('company', 'phone_number', 'Email', 'website')

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('course', 'Trainer')
    search_fields = ('course', )
    list_filter = ('Trainer',)



@admin.register(Trainer)
class TrainerAdmin(admin.ModelAdmin):
    list_display = ('name', 'course', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)

@admin.register(States)
class StatesAdmin(admin.ModelAdmin):
    list_display = ('state_name', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('state_name',)

@admin.register(Districts)
class DistrictsAdmin(admin.ModelAdmin):
    list_display = ('state', 'district', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('state__state_name', 'district')

@admin.register(Branches)
class BranchesAdmin(admin.ModelAdmin):
    list_display = ('branch', 'branch_code', 'adress', 'street', 'state', 'district', 'pincode', 'mobile_num', 'email', 'is_active')
    list_filter = ('is_active', 'state', 'district')
    search_fields = ('branch', 'branch_code', 'adress', 'street', 'state__state_name', 'district__district', 'pincode', 'mobile_num', 'email')

@admin.register(Enquiry_Source)
class EnquirySourceAdmin(admin.ModelAdmin):
    list_display = ('enquiry_source_name', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('enquiry_source_name',)

@admin.register(Follow_up_status)
class FollowUpStatusAdmin(admin.ModelAdmin):
    list_display = ('follow_up_status_name', 'follow_up_status', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('follow_up_status_name', 'follow_up_status')

@admin.register(Qualification)
class QualificationAdmin(admin.ModelAdmin):
    list_display = ('qualification_name', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('qualification_name',)

@admin.register(Batch)
class BatchAdmin(admin.ModelAdmin):
    list_display = ('batch', 'course','tutor', 'branch', 'start_date', 'end_date', 'closed', 'is_active')
    list_filter = ('closed', 'is_active', 'branch__state', 'branch__district')
    search_fields = ('batch', 'course__course', 'branch__branch')

@admin.register(Syllabus)
class SyllabusAdmin(admin.ModelAdmin):
    list_display = ('syllabus', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('syllabus',)

@admin.register(Slot)
class SlotAdmin(admin.ModelAdmin):
    list_display = ('time_slot','is_active')
    list_filter = ('is_active',)
    search_fields = ('time_slot',)


# @admin.register(Systems)
# class SystemsAdmin(admin.ModelAdmin):
#     list_display = ('add_system', 'is_active')
#     list_filter = ('is_active',)
#     search_fields = ('add_system',)


# @admin.register(Allocation)
# class AllocationAdmin(admin.ModelAdmin):
#     list_display = ('device', 'device_no', 'brand', 'is_active')
#     list_filter = ('is_active',)
#     search_fields = ('device__device_no', 'device_no', 'brand')


@admin.register(Device_num)
class DeviceNumAdmin(admin.ModelAdmin):
    list_display = ('device', 'device_no')
    search_fields = ('device', 'device_no')

@admin.register(Brands)
class BrandsAdmin(admin.ModelAdmin):
    list_display = ('device', 'brands')
    search_fields = ('device', 'brands')


@admin.register(Class)
class ClassAdmin(admin.ModelAdmin):
    list_display = ('class_name', 'is_active')
    search_fields = ('class_name',)