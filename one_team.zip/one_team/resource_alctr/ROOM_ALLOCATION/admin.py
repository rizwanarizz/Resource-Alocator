# # from django import forms
# # from django.contrib import admin
# # from .models import Class_room


# # class Class_roomForm(forms.ModelForm):
# #     class Meta:
# #         model = Class_room
# #         fields = '__all__'
# #         widgets = {
# #             'class_name': forms.Select(attrs={'class': 'select2'}),
# #             'slot': forms.Select(attrs={'class': 'select2'}),
# #         }

# #     def __init__(self, *args, **kwargs):
# #         super().__init__(*args, **kwargs)

# #         if 'class_name' in self.fields:
# #             # Get all slots
# #             all_slots = dict(Class_room.SLOT_CHOICES)
# #             # Exclude slots that have already been taken by any trainer
# #             taken_slots = Class_room.objects.exclude(slot__isnull=True).values_list('slot', flat=True)
# #             available_slots = [(key, value) for key, value in all_slots.items() if key not in taken_slots]
# #             self.fields['slot'].choices = available_slots

# # class Class_roomAdmin(admin.ModelAdmin):
# #     form = Class_roomForm
# #     list_display = ('class_name', 'trainers', 'slot')

# # admin.site.register(Class_room, Class_roomAdmin)







from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import Class_room

class CustomUserAdmin(BaseUserAdmin):
    filter_horizontal = ('slots',)

class Class_roomAdmin(admin.ModelAdmin):
    list_display = ('class_name', 'trainers', 'display_slots')

    def display_slots(self, obj):
        return ", ".join([str(slot) for slot in obj.slots.all()])
    
    display_slots.short_description = 'Slots'

admin.site.register(Class_room, Class_roomAdmin)








