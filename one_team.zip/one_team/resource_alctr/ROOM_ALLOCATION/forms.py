from SETTINGS.models import *
from django import forms
from .models import Class_room

class ClassRoomForm(forms.ModelForm):
    class Meta:
        model = Class_room
        fields = '__all__'

    class_name = forms.ModelChoiceField(queryset=Class.objects.all())
    slots = forms.ModelMultipleChoiceField(queryset=Slot.objects.all(), widget=forms.CheckboxSelectMultiple)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.pk:
            # If editing an existing instance, include the current slots in the form
            self.fields['slots'].initial = self.instance.slots.all()
