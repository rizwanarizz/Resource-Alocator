from django.db import models
from SETTINGS.models import *
from SETTINGS.models import Class, Trainer
from django.db.models.signals import m2m_changed
from django.dispatch import receiver

# Create your models here.
class Class_room(models.Model):
    class_name = models.ForeignKey(Class,on_delete=models.CASCADE)
    trainers = models.ForeignKey(Trainer,on_delete=models.CASCADE)
    # SLOT_CHOICES = [
    #     ('9.00 am - 10.30 am', '9.00 am - 10.30 am'),
    #     ('10.30 am - 12.00 pm', '10.30 am - 12.00 pm'),
    #     ('12.00 pm - 1.30 pm', '12.00 pm - 1.30 pm'),
    #     ('2.00 pm - 3.30 pm', '2.00 pm - 3.30 pm'),
    #     ('3.30 pm - 5.00 pm', '3.30 pm - 5.00 pm'),
    # ]
    # slot = models.CharField(max_length=100, choices=SLOT_CHOICES)
    # slot = models.ForeignKey(Slot,on_delete=models.CASCADE)
    slots = models.ManyToManyField(Slot,limit_choices_to={'class_room__isnull': True})

    def __str__(self):
        return f"{self.class_name} - {self.trainers}"
    
#     # Signal to handle slot removal when associated with a class_name
# @receiver(m2m_changed, sender=Class_room.slots.through)
# def remove_slots_associated_with_class_name(sender, instance, action, reverse, **kwargs):
#     if action == 'pre_clear' and not reverse:
#         # Slots are being cleared before updating
#         # We prevent clearing and remove the association instead
#         instance.slots.clear()


    