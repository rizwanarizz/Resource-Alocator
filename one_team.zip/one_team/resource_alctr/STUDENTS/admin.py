# from django.contrib import admin
# from .models import Students,Student_info

# # class StudentInfoInline(admin.TabularInline):
# #     model = Student_info
# #     # extra = 2

# class StudentsAdmin(admin.ModelAdmin):
#     fieldsets = [
#         ('GENERAL', {'fields': ['enquiry_source']}),
#         ('PHONE VERIFICATION',{'fields':['phone_num']}),
#         ('PERSONAL INFO',{'fields':['student','gender', 'Email', 'alternative_email', 'Adress', 'Alternative_adress', 'DOB', 'mobile', 'state', 'district', 'pincode', 'whatsapp_num']}),


#         ('ACADAMIC INFO',{'fields':['collage_name', 'year_of_pass_out', 'qualification', 'roll_num', 'reg_num']}),
#         ('COURSE INFO',{'fields':['course']}),
#         ('PHOTO',{'fields':['photo']}),
#         ('STUDENT CALL STATUS',{'fields':['student_call_status', 'next_follow_up_date','to_staff', 'comments']}),
#     ]
#     # inlines = [StudentInfoInline]


# class Student_infoAdmin(admin.ModelAdmin):
#     list_display = ['student', 'phone', 'email', 'batch', 'does_this_student_have_laptop', 'is_active']
#     list_filter = ['batch', 'does_this_student_have_laptop', 'is_active']
#     search_fields = ['student', 'phone', 'email']


# admin.site.register(Students, StudentsAdmin)
# admin.site.register(Student_info, Student_infoAdmin)


from django.contrib import admin
from .models import Students, Student_info
from django import forms




class StudentsAdmin(admin.ModelAdmin):
    list_display = ['student', 'Email','Student_info']

    fieldsets = [
        ('GENERAL', {
            'fields': ['enquiry_source'],
        }),
        ('PHONE VERIFICATION', {
            'fields': ['phone_num'],
        }),
        ('PERSONAL INFO', {
            'fields': [
                'student', 'gender', 'Email', 'alternative_email', 'Adress',
                'Alternative_adress', 'DOB', 'mobile', 'state', 'district', 'pincode', 'whatsapp_num'
            ],
            'classes': ['half-width'],
        }),
        ('ACADEMIC INFO', {
            'fields': ['collage_name', 'year_of_pass_out', 'qualification', 'roll_num', 'reg_num'],
            'classes': ['half-width'],
        }),
        ('COURSE INFO', {
            'fields': ['course'],
            'classes': ['half-width'],
        }),
        ('PHOTO', {
            'fields': ['photo'],
            'classes': ['half-width'],
        }),
        ('STUDENT CALL STATUS', {
            'fields': ['student_call_status', 'next_follow_up_date', 'to_staff', 'comments'],
            'classes': ['half-width'],
        }),
    ]


class Student_infoForm(forms.ModelForm):
    class Meta:
        model = Student_info
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        instance = kwargs.get('instance')

        if 'initial' in kwargs and 'request' in kwargs['initial']:
            # If 'request' is in 'initial', set the choices based on the current request's URL
            request = kwargs['initial']['request']
            student_info_id = request.path.split('/')[-2]  # Extract the student_info ID from the URL
            students = Students.objects.filter(student_info__id=student_info_id)
            choices = [(student.id, student.student) for student in students]
            self.fields['student'].widget.choices = choices
        elif instance:
            # Display a readonly field with the current student's name when editing
            self.fields['student'].widget = forms.TextInput(attrs={'readonly': 'readonly'})
            self.fields['student'].initial = instance.student

class Student_infoAdmin(admin.ModelAdmin):
    list_display = ['student', 'phone', 'email', 'batch', 'does_this_student_have_laptop','device_allocation','room_allocation','is_active']

    form = Student_infoForm



    

admin.site.register(Students, StudentsAdmin)
admin.site.register(Student_info, Student_infoAdmin)
