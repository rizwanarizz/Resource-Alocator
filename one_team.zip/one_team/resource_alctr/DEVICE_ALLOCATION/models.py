from django.db import models
from smart_selects.db_fields import ChainedForeignKey
from SETTINGS.models import *


# Create your models here.
class Device_allocation(models.Model):
    device_choice =  (('l','laptop'),('d','desktop'),)
    device = models.CharField(max_length=100,choices=device_choice)

    device_no = ChainedForeignKey(
        Device_num,
        chained_field="device",  # Use "device" as the chained field
        chained_model_field="device",  # Use "device" as the chained model field
        show_all=False,
        auto_choose=True,
        sort=True,
        on_delete=models.CASCADE,
        related_name="device_allocation_device_no",
    )
    

    brand = ChainedForeignKey(
        Brands,
        chained_field="device",  # Use "device" as the chained field
        chained_model_field="device",  # Use "device" as the chained model field
        show_all=False,
        auto_choose=True,
        sort=True,
        on_delete=models.CASCADE,
        related_name="device_allocation_brand",
    )


    is_active = models.BooleanField(default=True)
    


    # def __str__(self):
    #     return f'Device No: {self.device_no.device_no if self.device_no else ""}, Brand: {self.brand.brand if self.brand else ""}'

    def __str__(self):
        return f'{self.device_no}, {self.brand}'
    