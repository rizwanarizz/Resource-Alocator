from django.contrib import admin
from .models import Device_allocation

@admin.register(Device_allocation)
class DeviceAllocationAdmin(admin.ModelAdmin):
    list_display = ('device', 'device_no', 'brand', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('device__device_no', 'device_no__device_no', 'brand__brand') 